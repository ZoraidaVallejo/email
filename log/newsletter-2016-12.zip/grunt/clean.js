'use strict';

// Clean your /dist folder
module.exports = {
    images: ['dist/img/*', '!dist/img/*.json'],
    templates: ['dist/*.html']
};
